# Mapping table editor (Streamlit)

View and edit the BigQuery mapping table from your laptop. Every save is written
as the uploader service account and logged in an audit table: who, when,
old value, new value.

```
mapping-table-editor/
├── app.py                         Streamlit UI
├── changes.py                     change detection, validation, MERGE SQL (pure Python)
├── repository.py                  BigQuery access (+ in-memory demo backend)
├── config.py                      settings, defaults for wrk-int-wrk01-svp-cf82a1
├── requirements.txt
├── .streamlit/config.toml         binds to localhost only, telemetry off
├── terraform/audit_table.tf       audit table, add to your Terraform workspace
├── terraform/schema/mapping_table_audit.json
├── data/demo/                     sample data for demo mode
└── tests/                         36 tests (logic, mocked BigQuery, app smoke test)
```

## How it works

1. **Load:** reads the table's schema and rows straight from BigQuery (no query job needed).
2. **Edit:** cells, add rows, delete rows. The app checks types (whole numbers, decimals),
   required columns, duplicate or missing `account_id`, and blocks changes to `account_id` on existing rows.
3. **Save:** in one click the app:
   - checks the table hasn't changed since you loaded it (another save or a CSV upload). If it has, it refuses, so nothing is overwritten.
   - writes only the changed rows to two temporary staging tables, which auto-expire after 1 hour.
   - runs one transaction: `MERGE` the changes into the table **and** insert the audit rows. Both happen, or neither.
   - deletes the staging tables.
4. **History:** the *Change history* tab reads the audit table, filterable by `account_id`.

All jobs run as `mapping-table-uploader@…` (impersonated), use the HSM key `ew2-keyhsm-bigq-0de6`,
and stay in `europe-west2`.

## One-time setup

### 1. Create the audit table (Terraform)
Copy `terraform/audit_table.tf` and `terraform/schema/mapping_table_audit.json` into the
Terraform workspace that manages the mapping table. Adjust the marked lines (dataset reference,
labels) to match that workspace, then let the pipeline apply it. Expect **1 to add**.

Until it exists, the app opens read-only and shows a warning.

### 2. Python environment
Python 3.10 or later:

```bash
cd mapping-table-editor
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

If `pip` can't reach the internet from your laptop, use your company's Python package mirror
(e.g. `pip install -r requirements.txt --index-url <mirror URL>`).

### 3. Log in for applications, with your work account
The app uses your *application* login (not the same as `gcloud auth login`):

```bash
gcloud auth application-default login      # choose your @lloydsbanking.com account
```

Check it works, on the VPN:

```bash
gcloud auth print-access-token --impersonate-service-account=mapping-table-uploader@wrk-int-wrk01-svp-cf82a1.iam.gserviceaccount.com > /dev/null && echo "impersonation OK"
```

## Run

On the VPN:

```bash
source .venv/bin/activate
streamlit run app.py
```

It opens at http://localhost:8501. To try it without GCP, with sample data in memory:

```bash
MAPPING_DEMO=1 streamlit run app.py
```

## Using it

| To | Do this |
| --- | --- |
| Edit a cell | Double-click it, type, press Enter |
| Add a row | Click **+** at the top right of the table, fill in `account_id` and the other columns |
| Delete rows | Tick the box at the left of each row, press Delete, then tick the confirmation under the table |
| Check before saving | Open **Review N change(s)** under the counters |
| Save | **Save changes**. It's disabled while there are errors or nothing to save |
| Undo unsaved edits | **Discard changes** |
| Get the latest data | **Reload from BigQuery** in the sidebar (discards unsaved edits) |
| Fewer columns on screen | Sidebar → **Columns to show**. Hidden columns keep their values |
| Back up or bulk edit | Sidebar → **Export table as CSV** (original headers, same order as the upload script) |
| See who changed what | **Change history** tab |

## Settings

Defaults match `wrk-int-wrk01-svp-cf82a1`. Override them with environment variables:

| Variable | Default |
| --- | --- |
| `MAPPING_PROJECT` | `wrk-int-wrk01-svp-cf82a1` |
| `MAPPING_DATASET` | `ew2_wrk_int_wrk01_svp_bqd_reference_data` |
| `MAPPING_TABLE` | `mapping-table` |
| `MAPPING_AUDIT_TABLE` | `mapping-table-audit` |
| `MAPPING_UPLOADER_SA` | `mapping-table-uploader@<project>.iam.gserviceaccount.com` (empty = run as yourself) |
| `MAPPING_KMS_KEY` | `projects/<project>/locations/europe-west2/keyRings/ew2-krs-bigq-0de6/cryptoKeys/ew2-keyhsm-bigq-0de6` |
| `MAPPING_LOCATION` | `europe-west2` |
| `MAPPING_KEY_COLUMN` | `account_id` |
| `MAPPING_EDITOR_EMAIL` | (detected from your login) the name written to the audit log |
| `MAPPING_DEMO` | `0` (`1` = sample data, no GCP) |

## The app is now the master copy

Edits made in the app live only in BigQuery. **A CSV upload with `upload_mapping.sh` replaces
every row and wipes them.** Use the CSV upload only for deliberate bulk reloads:

1. **Export table as CSV** from the app first.
2. Make the bulk changes in that file.
3. Upload it, then click **Reload from BigQuery** in the app.

Bulk uploads aren't recorded in the audit table, only app edits are. To stop accidental
overwrites, add this guard to `upload_mapping.sh`, just before the `bq load` command:

```bash
if [[ "${FORCE:-}" != "1" ]]; then
  echo "WARNING: this REPLACES every row in the mapping table, including edits made in the editor app."
  echo "Export the table from the app first if you need to keep them."
  read -r -p "Type REPLACE to continue: " answer
  [[ "$answer" == "REPLACE" ]] || { echo "Cancelled. Nothing was uploaded."; exit 1; }
fi
```

(`FORCE=1 ./upload_mapping.sh …` skips the prompt, for scripted runs.)

## Troubleshooting

| Message | Cause | Fix |
| --- | --- | --- |
| `VPC Service Controls: Request is prohibited…` | Off the VPN | Connect to the VPN, click **Try again** |
| `Failed to impersonate … getAccessToken` | Missing Token Creator, or the application login is the wrong account | `gcloud auth application-default login` with your work account; check `uploader_members` |
| `Your administrator requires that you specify an encryption key` | A job ran without the CMEK key | Check `MAPPING_KMS_KEY`. The lasting fix is a project default key, set once by the platform team: `ALTER PROJECT \`wrk-int-wrk01-svp-cf82a1\` SET OPTIONS (\`region-europe-west2.default_kms_key_name\` = '<key path>');` |
| `Audit table … doesn't exist yet` | Terraform for the audit table not applied | Step 1 of setup |
| `The table changed after you loaded it` | Someone saved or uploaded since you loaded | Note your edits, **Reload from BigQuery**, edit again |
| Save fails with `Transaction is aborted due to concurrent update` | Another save landed at the same moment | Reload and retry |

## Tests

```bash
pip install -r requirements.txt
python -m pytest -q tests
```

The tests cover change detection and validation, the BigQuery calls (mocked: staging, CMEK on
every job, the MERGE transaction, clean-up, the concurrent-change check), and an app smoke test
in demo mode.
