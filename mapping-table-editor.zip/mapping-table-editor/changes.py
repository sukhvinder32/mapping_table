"""Pure logic for the mapping-table editor (no BigQuery, no Streamlit).

Turns the Streamlit data-editor state into:
  * upserts  - full rows to insert or update (keyed by account_id)
  * deletes  - keys to delete
  * audit    - one audit record per changed cell / added row / deleted row
  * errors   - validation problems that block saving

Also builds the MERGE transaction that applies a change set.
"""
from __future__ import annotations

import json
import math
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN
from typing import Any, Iterable, Mapping, Sequence

NUMERIC_QUANTUM = Decimal("0.000000001")  # BigQuery NUMERIC: 9 decimal places
STAGE_OP_COLUMN = "_op"

AUDIT_SCHEMA: list[tuple[str, str]] = [
    ("change_id", "STRING"),
    ("batch_id", "STRING"),
    ("changed_at", "TIMESTAMP"),
    ("changed_by", "STRING"),
    ("action", "STRING"),        # INSERT | UPDATE | DELETE
    ("account_id", "STRING"),
    ("column_name", "STRING"),   # set for UPDATE only
    ("old_value", "STRING"),     # UPDATE: old cell; DELETE: whole row as JSON
    ("new_value", "STRING"),     # UPDATE: new cell; INSERT: whole row as JSON
    ("source", "STRING"),
]


@dataclass(frozen=True)
class Column:
    name: str
    type: str            # BigQuery type, e.g. STRING, INT64, NUMERIC
    mode: str = "NULLABLE"
    description: str = ""

    @property
    def required(self) -> bool:
        return self.mode.upper() == "REQUIRED"


@dataclass
class ChangeSet:
    upserts: list[dict[str, Any]] = field(default_factory=list)
    deletes: list[str] = field(default_factory=list)
    audit: list[dict[str, Any]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    updated: int = 0
    added: int = 0

    @property
    def deleted(self) -> int:
        return len(self.deletes)

    @property
    def is_empty(self) -> bool:
        return not (self.upserts or self.deletes)

    @property
    def can_save(self) -> bool:
        return not self.is_empty and not self.errors


# --------------------------------------------------------------------------- #
# Value handling
# --------------------------------------------------------------------------- #
def _is_blank(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    if isinstance(value, str) and value.strip() == "":
        return True
    try:  # pandas NA / NaT
        import pandas as pd  # local import keeps this module light

        if value is pd.NA or value is pd.NaT:
            return True
    except ImportError:  # pragma: no cover
        pass
    return False


def coerce(value: Any, bq_type: str) -> Any:
    """Convert an editor value to the JSON-safe form BigQuery loads for bq_type.

    Returns None for blanks. Raises ValueError with a readable message.
    STRING -> str, INT64 -> int, NUMERIC/BIGNUMERIC -> str (exact decimal),
    FLOAT64 -> float, BOOL -> bool, DATE/DATETIME/TIMESTAMP -> ISO str.
    """
    if _is_blank(value):
        return None
    t = bq_type.upper()

    if t == "STRING":
        return str(value)

    if t in ("INT64", "INTEGER"):
        if isinstance(value, bool):
            raise ValueError(f"'{value}' is not a whole number")
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if value.is_integer():
                return int(value)
            raise ValueError(f"'{value}' is not a whole number")
        if isinstance(value, Decimal):
            if value == value.to_integral_value():
                return int(value)
            raise ValueError(f"'{value}' is not a whole number")
        text = str(value).strip().replace(",", "")
        try:
            d = Decimal(text)
        except InvalidOperation:
            raise ValueError(f"'{value}' is not a whole number") from None
        if d != d.to_integral_value():
            raise ValueError(f"'{value}' is not a whole number")
        return int(d)

    if t in ("NUMERIC", "BIGNUMERIC", "DECIMAL", "BIGDECIMAL"):
        if isinstance(value, bool):
            raise ValueError(f"'{value}' is not a number")
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError(f"'{value}' is not a number")
            d = Decimal(repr(value))
        elif isinstance(value, (int, Decimal)):
            d = Decimal(value)
        else:
            text = str(value).strip().replace(",", "")
            try:
                d = Decimal(text)
            except InvalidOperation:
                raise ValueError(f"'{value}' is not a number") from None
        if not d.is_finite():
            raise ValueError(f"'{value}' is not a number")
        d = d.quantize(NUMERIC_QUANTUM, rounding=ROUND_HALF_EVEN).normalize()
        return format(d, "f")

    if t in ("FLOAT64", "FLOAT"):
        try:
            f = float(str(value).replace(",", "")) if isinstance(value, str) else float(value)
        except (TypeError, ValueError):
            raise ValueError(f"'{value}' is not a number") from None
        if not math.isfinite(f):
            raise ValueError(f"'{value}' is not a number")
        return f

    if t in ("BOOL", "BOOLEAN"):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in ("true", "t", "yes", "y", "1"):
            return True
        if text in ("false", "f", "no", "n", "0"):
            return False
        raise ValueError(f"'{value}' is not true/false")

    if t in ("DATE", "DATETIME", "TIMESTAMP"):
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        return str(value).strip()

    # Unknown / complex types: pass through as text.
    return str(value)


def display_value(value: Any) -> str | None:
    """Text form of a coerced value, for the audit log."""
    if value is None:
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, Decimal):
        return format(value.normalize(), "f")
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return str(value)


def _safe_coerce(value: Any, bq_type: str) -> Any:
    """Coerce a value that came from BigQuery itself (never raises)."""
    try:
        return coerce(value, bq_type)
    except ValueError:
        return display_value(value)


def _row_json(row: Mapping[str, Any]) -> str:
    """Whole row as JSON (values are already coerced: str/int/float/bool/None)."""
    return json.dumps(dict(row), default=str)


# --------------------------------------------------------------------------- #
# Change detection
# --------------------------------------------------------------------------- #
def build_changeset(
    original_rows: Sequence[Mapping[str, Any]],
    columns: Sequence[Column],
    editor_state: Mapping[str, Any] | None,
    key: str,
    changed_by: str,
    *,
    now: datetime | None = None,
    batch_id: str | None = None,
    source: str = "streamlit-editor",
) -> ChangeSet:
    """Translate Streamlit data_editor state into a validated ChangeSet.

    original_rows  rows exactly as passed to st.data_editor (same order).
    editor_state   st.session_state[<editor key>]:
                   {"edited_rows": {pos: {col: val}}, "added_rows": [...], "deleted_rows": [pos]}
    """
    cs = ChangeSet()
    state = editor_state or {}
    edited: Mapping[Any, Mapping[str, Any]] = state.get("edited_rows", {}) or {}
    added: Iterable[Mapping[str, Any]] = state.get("added_rows", []) or []
    deleted_positions = sorted({int(p) for p in (state.get("deleted_rows", []) or [])})

    col_by_name = {c.name: c for c in columns}
    if key not in col_by_name:
        cs.errors.append(f"Key column '{key}' is not in the table schema.")
        return cs
    key_type = col_by_name[key].type

    now = now or datetime.now(timezone.utc)
    batch_id = batch_id or uuid.uuid4().hex[:12]
    stamp = now.isoformat()

    def audit(action: str, account: str, column: str | None, old: str | None, new: str | None) -> None:
        cs.audit.append(
            {
                "change_id": uuid.uuid4().hex,
                "batch_id": batch_id,
                "changed_at": stamp,
                "changed_by": changed_by,
                "action": action,
                "account_id": account,
                "column_name": column,
                "old_value": old,
                "new_value": new,
                "source": source,
            }
        )

    def label(pos: int) -> str:
        if 0 <= pos < len(original_rows):
            k = original_rows[pos].get(key)
            return f"row {pos + 1} ({key} {k})"
        return f"row {pos + 1}"

    existing_keys = {
        display_value(_safe_coerce(r.get(key), key_type)) for r in original_rows
    }

    # ---- deletions (win over edits to the same row) ----------------------- #
    for pos in deleted_positions:
        if not 0 <= pos < len(original_rows):
            cs.errors.append(f"Deleted row position {pos} is out of range; reload and try again.")
            continue
        orig = original_rows[pos]
        k = display_value(_safe_coerce(orig.get(key), key_type))
        if k is None:
            cs.errors.append(f"{label(pos)} has no {key} and can't be deleted from the app.")
            continue
        cs.deletes.append(k)
        audit("DELETE", k, None, _row_json({c.name: _safe_coerce(orig.get(c.name), c.type) for c in columns}), None)
    deleted_set = set(deleted_positions)

    # ---- edits to existing rows ------------------------------------------- #
    for raw_pos, changes in sorted(edited.items(), key=lambda kv: int(kv[0])):
        pos = int(raw_pos)
        if pos in deleted_set:
            continue
        if not 0 <= pos < len(original_rows):
            cs.errors.append(f"Edited row position {pos} is out of range; reload and try again.")
            continue
        orig = original_rows[pos]
        k = display_value(_safe_coerce(orig.get(key), key_type))
        new_row = {c.name: _safe_coerce(orig.get(c.name), c.type) for c in columns}
        row_errors: list[str] = []
        row_changes: list[tuple[str, Any, Any]] = []

        for col_name, new_value in changes.items():
            col = col_by_name.get(col_name)
            if col is None:
                continue  # e.g. a UI-only column
            try:
                new_c = coerce(new_value, col.type)
            except ValueError as exc:
                row_errors.append(f"{label(pos)}, column {col_name}: {exc}")
                continue
            old_c = new_row[col_name]
            if new_c == old_c:
                continue
            if col_name == key:
                row_errors.append(
                    f"{label(pos)}: {key} can't be changed. Delete the row and add a new one instead."
                )
                continue
            if col.required and new_c is None:
                row_errors.append(f"{label(pos)}, column {col_name}: a value is required.")
                continue
            new_row[col_name] = new_c
            row_changes.append((col_name, old_c, new_c))

        if row_errors:
            cs.errors.extend(row_errors)
            continue
        if not row_changes:
            continue
        cs.upserts.append(new_row)
        cs.updated += 1
        for col_name, old_c, new_c in row_changes:
            audit("UPDATE", k, col_name, display_value(old_c), display_value(new_c))

    # ---- added rows ------------------------------------------------------- #
    seen_new: set[str] = set()
    for idx, raw in enumerate(added, start=1):
        new_row: dict[str, Any] = {}
        row_errors = []
        for col in columns:
            try:
                new_row[col.name] = coerce(raw.get(col.name), col.type)
            except ValueError as exc:
                row_errors.append(f"New row {idx}, column {col.name}: {exc}")
                new_row[col.name] = None
        if all(v is None for v in new_row.values()) and not row_errors:
            continue  # an empty row the user added and never filled in
        k = display_value(new_row.get(key))
        if k is None:
            row_errors.append(f"New row {idx}: {key} is required.")
        elif k in existing_keys:
            row_errors.append(f"New row {idx}: {key} {k} already exists.")
        elif k in seen_new:
            row_errors.append(f"New row {idx}: {key} {k} is entered twice.")
        for col in columns:
            if col.required and col.name != key and new_row.get(col.name) is None:
                row_errors.append(f"New row {idx}, column {col.name}: a value is required.")
        if row_errors:
            cs.errors.extend(row_errors)
            continue
        seen_new.add(k)
        cs.upserts.append(new_row)
        cs.added += 1
        audit("INSERT", k, None, None, _row_json(new_row))

    return cs


def stage_rows(cs: ChangeSet, columns: Sequence[Column], key: str) -> list[dict[str, Any]]:
    """Rows for the staging table: every upsert in full, deletes as key only."""
    rows = [{**r, STAGE_OP_COLUMN: "UPSERT"} for r in cs.upserts]
    for k in cs.deletes:
        row = {c.name: None for c in columns}
        row[key] = coerce(k, next(c.type for c in columns if c.name == key))
        row[STAGE_OP_COLUMN] = "DELETE"
        rows.append(row)
    return rows


# --------------------------------------------------------------------------- #
# SQL
# --------------------------------------------------------------------------- #
def quote_ident(name: str) -> str:
    if "`" in name:
        raise ValueError(f"Invalid identifier: {name}")
    return f"`{name}`"


def merge_transaction_sql(
    target_table: str,
    stage_table: str,
    audit_table: str,
    audit_stage_table: str,
    columns: Sequence[Column],
    key: str,
) -> str:
    """One atomic script: apply the staged changes and write the audit rows."""
    names = [c.name for c in columns]
    if key not in names:
        raise ValueError(f"Key column '{key}' missing")
    t, s = quote_ident(target_table), quote_ident(stage_table)
    a, as_ = quote_ident(audit_table), quote_ident(audit_stage_table)
    k = quote_ident(key)
    op = quote_ident(STAGE_OP_COLUMN)
    set_list = ",\n      ".join(f"{quote_ident(n)} = S.{quote_ident(n)}" for n in names if n != key)
    col_list = ", ".join(quote_ident(n) for n in names)
    val_list = ", ".join(f"S.{quote_ident(n)}" for n in names)
    audit_cols = ", ".join(quote_ident(n) for n, _ in AUDIT_SCHEMA)
    return f"""BEGIN TRANSACTION;

MERGE {t} AS T
USING {s} AS S
ON T.{k} = S.{k}
WHEN MATCHED AND S.{op} = 'DELETE' THEN
  DELETE
WHEN MATCHED AND S.{op} = 'UPSERT' THEN
  UPDATE SET
      {set_list}
WHEN NOT MATCHED BY TARGET AND S.{op} = 'UPSERT' THEN
  INSERT ({col_list})
  VALUES ({val_list});

INSERT INTO {a} ({audit_cols})
SELECT {audit_cols} FROM {as_};

COMMIT TRANSACTION;
"""
