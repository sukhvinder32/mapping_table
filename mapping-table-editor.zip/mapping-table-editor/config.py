"""Settings for the mapping-table editor.

Defaults match the wrk-int-wrk01-svp-cf82a1 deployment. Override any of them
with environment variables, e.g. `export MAPPING_TABLE=mapping-table`.
"""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    project: str
    dataset: str
    table: str
    audit_table: str
    uploader_sa: str
    kms_key: str
    location: str
    key_column: str
    editor_email: str
    demo: bool

    @property
    def table_id(self) -> str:
        return f"{self.project}.{self.dataset}.{self.table}"

    @property
    def audit_table_id(self) -> str:
        return f"{self.project}.{self.dataset}.{self.audit_table}"


def _env(name: str, default: str) -> str:
    value = os.environ.get(name)
    return value if value not in (None, "") else default


def load_settings() -> Settings:
    project = _env("MAPPING_PROJECT", "wrk-int-wrk01-svp-cf82a1")
    return Settings(
        project=project,
        dataset=_env("MAPPING_DATASET", "ew2_wrk_int_wrk01_svp_bqd_reference_data"),
        table=_env("MAPPING_TABLE", "mapping-table"),
        audit_table=_env("MAPPING_AUDIT_TABLE", "mapping-table-audit"),
        uploader_sa=_env(
            "MAPPING_UPLOADER_SA",
            f"mapping-table-uploader@{project}.iam.gserviceaccount.com",
        ),
        kms_key=_env(
            "MAPPING_KMS_KEY",
            f"projects/{project}/locations/europe-west2/keyRings/ew2-krs-bigq-0de6"
            "/cryptoKeys/ew2-keyhsm-bigq-0de6",
        ),
        location=_env("MAPPING_LOCATION", "europe-west2"),
        key_column=_env("MAPPING_KEY_COLUMN", "account_id"),
        editor_email=_env("MAPPING_EDITOR_EMAIL", ""),
        demo=_env("MAPPING_DEMO", "0").lower() in ("1", "true", "yes"),
    )
