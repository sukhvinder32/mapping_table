"""Data access for the mapping-table editor.

BigQueryRepository  - the real thing: every call runs as the uploader service
                      account (impersonation), every job uses the CMEK key.
DemoRepository      - in-memory copy of a sample CSV, for trying the app
                      without GCP access (MAPPING_DEMO=1) and for tests.
"""
from __future__ import annotations

import csv
import getpass
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Protocol, Sequence

from changes import AUDIT_SCHEMA, STAGE_OP_COLUMN, ChangeSet, Column, coerce, merge_transaction_sql, stage_rows

CLOUD_SCOPE = "https://www.googleapis.com/auth/cloud-platform"


class ConcurrentModificationError(RuntimeError):
    """The table changed after it was loaded into the editor."""


@dataclass
class Snapshot:
    columns: list[Column]
    rows: list[dict[str, Any]]
    version: str
    loaded_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class Repository(Protocol):
    def acting_as(self) -> str: ...
    def signed_in_as(self) -> str: ...
    def load(self) -> Snapshot: ...
    def audit_status(self) -> tuple[bool, str]: ...
    def save(self, cs: ChangeSet, columns: Sequence[Column], expected_version: str) -> None: ...
    def recent_changes(self, limit: int = 200, account_id: str | None = None) -> list[dict[str, Any]]: ...


# =========================================================================== #
# BigQuery
# =========================================================================== #
class BigQueryRepository:
    def __init__(self, settings):
        import google.auth
        from google.auth import impersonated_credentials
        from google.cloud import bigquery

        self.s = settings
        self._bq = bigquery
        source, _ = google.auth.default(scopes=[CLOUD_SCOPE])
        self._source = source
        if settings.uploader_sa:
            creds = impersonated_credentials.Credentials(
                source_credentials=source,
                target_principal=settings.uploader_sa,
                target_scopes=[CLOUD_SCOPE],
                lifetime=3600,
            )
        else:
            creds = source
        self.client = bigquery.Client(
            project=settings.project, credentials=creds, location=settings.location
        )
        self._email: str | None = None

    # ---- identity --------------------------------------------------------- #
    def acting_as(self) -> str:
        return self.s.uploader_sa or "your own account"

    def signed_in_as(self) -> str:
        if self._email:
            return self._email
        email = self.s.editor_email
        if not email:
            email = getattr(self._source, "service_account_email", "") or ""
            if "@" not in email:
                email = self._email_from_token() or ""
        self._email = email or getpass.getuser()
        return self._email

    def _email_from_token(self) -> str | None:
        try:
            import requests
            from google.auth.transport.requests import Request

            if not self._source.valid:
                self._source.refresh(Request())
            r = requests.get(
                "https://oauth2.googleapis.com/tokeninfo",
                params={"access_token": self._source.token},
                timeout=10,
            )
            return r.json().get("email") if r.ok else None
        except Exception:
            return None

    # ---- helpers ---------------------------------------------------------- #
    def _encryption(self):
        if not self.s.kms_key:
            return None
        return self._bq.EncryptionConfiguration(kms_key_name=self.s.kms_key)

    def _query(self, sql: str, params: list | None = None) -> list[dict[str, Any]]:
        """Run SQL with the CMEK key; retry without it only if BigQuery rejects the key setting."""
        from google.api_core.exceptions import BadRequest

        def config(with_key: bool):
            cfg = self._bq.QueryJobConfig(query_parameters=params or [])
            if with_key and self.s.kms_key:
                cfg.destination_encryption_configuration = self._encryption()
            return cfg

        try:
            result = self.client.query(sql, job_config=config(True)).result()
        except BadRequest as exc:
            if self.s.kms_key and "encryption" in str(exc).lower():
                result = self.client.query(sql, job_config=config(False)).result()
            else:
                raise
        return [dict(row.items()) for row in result]

    @staticmethod
    def _columns(schema) -> list[Column]:
        return [Column(f.name, f.field_type, f.mode or "NULLABLE", f.description or "") for f in schema]

    # ---- reads ------------------------------------------------------------ #
    def load(self) -> Snapshot:
        table = self.client.get_table(self.s.table_id)
        nested = [f.name for f in table.schema if f.field_type in ("RECORD", "STRUCT") or f.mode == "REPEATED"]
        if nested:
            raise RuntimeError(f"Nested/repeated columns aren't supported by this editor: {', '.join(nested)}")
        columns = self._columns(table.schema)
        rows = [dict(r.items()) for r in self.client.list_rows(table)]  # no query job, no CMEK needed
        key = self.s.key_column
        rows.sort(key=lambda r: str(r.get(key) or ""))
        version = table.modified.isoformat() if table.modified else ""
        return Snapshot(columns=columns, rows=rows, version=version)

    def audit_status(self) -> tuple[bool, str]:
        from google.api_core.exceptions import NotFound

        try:
            self.client.get_table(self.s.audit_table_id)
            return True, ""
        except NotFound:
            return False, (
                f"Audit table `{self.s.audit_table_id}` doesn't exist yet, so saving is disabled. "
                "Create it with terraform/audit_table.tf (see README)."
            )

    def recent_changes(self, limit: int = 200, account_id: str | None = None) -> list[dict[str, Any]]:
        bq = self._bq
        where = "WHERE account_id = @account_id" if account_id else ""
        sql = (
            "SELECT changed_at, changed_by, action, account_id, column_name, old_value, new_value, batch_id "
            f"FROM `{self.s.audit_table_id}` {where} ORDER BY changed_at DESC LIMIT @limit"
        )
        params = [bq.ScalarQueryParameter("limit", "INT64", int(limit))]
        if account_id:
            params.append(bq.ScalarQueryParameter("account_id", "STRING", account_id))
        return self._query(sql, params)

    # ---- writes ----------------------------------------------------------- #
    def save(self, cs: ChangeSet, columns: Sequence[Column], expected_version: str) -> None:
        if not cs.can_save:
            raise ValueError("Nothing valid to save.")
        bq = self._bq
        current = self.client.get_table(self.s.table_id)
        current_version = current.modified.isoformat() if current.modified else ""
        if current_version != expected_version:
            raise ConcurrentModificationError(current_version)

        batch = (cs.audit[0]["batch_id"] if cs.audit else uuid.uuid4().hex[:12]).replace("-", "")
        base = f"{self.s.project}.{self.s.dataset}"
        stage_id = f"{base}._tmp_mapping_stage_{batch}"
        audit_stage_id = f"{base}._tmp_mapping_audit_stage_{batch}"
        stage_schema = [bq.SchemaField(c.name, c.type, mode="NULLABLE") for c in columns]
        stage_schema.append(bq.SchemaField(STAGE_OP_COLUMN, "STRING", mode="NULLABLE"))
        audit_schema = [bq.SchemaField(n, t, mode="NULLABLE") for n, t in AUDIT_SCHEMA]

        try:
            self._create_stage(stage_id, stage_schema)
            self._create_stage(audit_stage_id, audit_schema)
            self._load_json(stage_id, stage_rows(cs, columns, self.s.key_column), stage_schema)
            self._load_json(audit_stage_id, cs.audit, audit_schema)
            self._query(
                merge_transaction_sql(
                    target_table=self.s.table_id,
                    stage_table=stage_id,
                    audit_table=self.s.audit_table_id,
                    audit_stage_table=audit_stage_id,
                    columns=columns,
                    key=self.s.key_column,
                )
            )
        finally:
            for table_id in (stage_id, audit_stage_id):
                try:
                    self.client.delete_table(table_id, not_found_ok=True)
                except Exception:
                    pass  # stage tables also expire on their own after 1 hour

    def _create_stage(self, table_id: str, schema) -> None:
        table = self._bq.Table(table_id, schema=schema)
        table.expires = datetime.now(timezone.utc) + timedelta(hours=1)
        if self.s.kms_key:
            table.encryption_configuration = self._encryption()
        table.description = "Temporary staging table for the mapping-table editor (auto-expires)."
        self.client.create_table(table)

    def _load_json(self, table_id: str, rows: list[dict[str, Any]], schema) -> None:
        if not rows:
            return
        bq = self._bq
        cfg = bq.LoadJobConfig(
            schema=schema,
            source_format=bq.SourceFormat.NEWLINE_DELIMITED_JSON,
            write_disposition=bq.WriteDisposition.WRITE_TRUNCATE,
        )
        if self.s.kms_key:
            cfg.destination_encryption_configuration = self._encryption()
        self.client.load_table_from_json(rows, table_id, job_config=cfg).result()


# =========================================================================== #
# Demo (in memory)
# =========================================================================== #
class DemoRepository:
    """Behaves like BigQueryRepository, backed by a CSV + schema JSON in memory."""

    def __init__(self, csv_path: Path, schema_path: Path, key: str = "account_id", user: str = "demo.user@example.com"):
        spec = json.loads(Path(schema_path).read_text())
        self.columns = [Column(f["name"], f["type"], f.get("mode", "NULLABLE"), f.get("description", "")) for f in spec]
        self.key = key
        self.user = user
        self.rows: list[dict[str, Any]] = []
        with open(csv_path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.reader(fh)
            next(reader)  # header
            for raw in reader:
                if not any(v.strip() for v in raw):
                    continue
                self.rows.append({c.name: self._from_csv(v, c.type) for c, v in zip(self.columns, raw)})
        self.rows.sort(key=lambda r: str(r.get(key) or ""))
        self.audit: list[dict[str, Any]] = []
        self.version = 1

    @staticmethod
    def _from_csv(value: str, bq_type: str):
        from decimal import Decimal

        v = coerce(value, bq_type)
        if v is not None and bq_type.upper() in ("NUMERIC", "BIGNUMERIC"):
            return Decimal(v)
        return v

    def acting_as(self) -> str:
        return "demo mode (no GCP connection)"

    def signed_in_as(self) -> str:
        return self.user

    def load(self) -> Snapshot:
        return Snapshot(columns=list(self.columns), rows=[dict(r) for r in self.rows], version=str(self.version))

    def audit_status(self) -> tuple[bool, str]:
        return True, ""

    def recent_changes(self, limit: int = 200, account_id: str | None = None) -> list[dict[str, Any]]:
        keep = ("changed_at", "changed_by", "action", "account_id", "column_name", "old_value", "new_value", "batch_id")
        rows = [{k: a.get(k) for k in keep} for a in self.audit if not account_id or a["account_id"] == account_id]
        rows.sort(key=lambda a: a["changed_at"], reverse=True)
        return rows[:limit]

    def save(self, cs: ChangeSet, columns: Sequence[Column], expected_version: str) -> None:
        from decimal import Decimal

        if not cs.can_save:
            raise ValueError("Nothing valid to save.")
        if expected_version != str(self.version):
            raise ConcurrentModificationError(str(self.version))
        by_key = {str(r[self.key]): r for r in self.rows}
        for k in cs.deletes:
            by_key.pop(k, None)
        for up in cs.upserts:
            row = {
                c.name: (Decimal(up[c.name]) if up[c.name] is not None and c.type.upper() == "NUMERIC" else up[c.name])
                for c in columns
            }
            by_key[str(row[self.key])] = row
        self.rows = sorted(by_key.values(), key=lambda r: str(r.get(self.key) or ""))
        self.audit.extend(dict(a) for a in cs.audit)
        self.version += 1
