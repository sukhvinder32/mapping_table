"""Streamlit editor for the BigQuery mapping table.

Run:  streamlit run app.py              (real table, on VPN)
      MAPPING_DEMO=1 streamlit run app.py   (sample data, no GCP)
"""
from __future__ import annotations

import io
from decimal import Decimal
from pathlib import Path

import pandas as pd
import streamlit as st

from changes import Column, build_changeset
from config import Settings, load_settings
from repository import BigQueryRepository, ConcurrentModificationError, DemoRepository

st.set_page_config(page_title="Mapping table editor", layout="wide")

HERE = Path(__file__).parent
NUMERIC_TYPES = {"NUMERIC", "BIGNUMERIC", "FLOAT64", "FLOAT", "DECIMAL", "BIGDECIMAL"}
INT_TYPES = {"INT64", "INTEGER"}
BOOL_TYPES = {"BOOL", "BOOLEAN"}


# --------------------------------------------------------------------------- #
# Setup
# --------------------------------------------------------------------------- #
@st.cache_resource(show_spinner="Connecting to BigQuery…")
def get_repository(settings: Settings):
    if settings.demo:
        return DemoRepository(
            HERE / "data" / "demo" / "MappingTable.csv",
            HERE / "data" / "demo" / "mapping_table.json",
            key=settings.key_column,
        )
    return BigQueryRepository(settings)


def original_header(col: Column) -> str:
    prefix = "Source column: "
    return col.description[len(prefix):] if col.description.startswith(prefix) else col.name


def to_frame(columns: list[Column], rows: list[dict]) -> pd.DataFrame:
    data = {}
    for c in columns:
        values = [r.get(c.name) for r in rows]
        t = c.type.upper()
        if t in INT_TYPES:
            data[c.name] = pd.array(values, dtype="Int64")
        elif t in NUMERIC_TYPES:
            data[c.name] = pd.array(
                [float(v) if isinstance(v, (Decimal, int, float)) else None for v in values], dtype="Float64"
            )
        elif t in BOOL_TYPES:
            data[c.name] = pd.array(values, dtype="boolean")
        else:
            data[c.name] = pd.array([None if v is None else str(v) for v in values], dtype="object")
    return pd.DataFrame(data, columns=[c.name for c in columns])


def column_config(columns: list[Column], key: str) -> dict:
    cfg = {}
    for c in columns:
        header = original_header(c)
        help_text = f"Original header: {header}" if header != c.name else None
        t = c.type.upper()
        if c.name == key:
            cfg[c.name] = st.column_config.TextColumn(
                c.name, help="Key. Set it on new rows; it can't be changed on existing rows.",
                required=True, pinned=True,
            )
        elif t in INT_TYPES:
            cfg[c.name] = st.column_config.NumberColumn(c.name, help=help_text, step=1, format="%d", required=c.required)
        elif t in NUMERIC_TYPES:
            cfg[c.name] = st.column_config.NumberColumn(c.name, help=help_text, required=c.required)
        elif t in BOOL_TYPES:
            cfg[c.name] = st.column_config.CheckboxColumn(c.name, help=help_text)
        else:
            cfg[c.name] = st.column_config.TextColumn(c.name, help=help_text, required=c.required)
    return cfg


def export_csv(columns: list[Column], rows: list[dict]) -> bytes:
    """Current table as CSV: original headers, same column order the upload script expects."""
    out = io.StringIO()
    frame = pd.DataFrame(
        [[("" if r.get(c.name) is None else r.get(c.name)) for c in columns] for r in rows],
        columns=[original_header(c) for c in columns],
    )
    frame.to_csv(out, index=False)
    return out.getvalue().encode("utf-8")


def reload_snapshot(repo) -> None:
    st.session_state.snapshot = repo.load()
    st.session_state.editor_version = st.session_state.get("editor_version", 0) + 1
    st.session_state.history = None


# --------------------------------------------------------------------------- #
# Connect + load
# --------------------------------------------------------------------------- #
settings = load_settings()
try:
    repo = get_repository(settings)
    if "snapshot" not in st.session_state:
        with st.spinner("Loading the mapping table…"):
            reload_snapshot(repo)
    user = repo.signed_in_as()
except Exception as exc:  # noqa: BLE001 - show any connection problem to the user
    st.title("Mapping table editor")
    st.error(f"Couldn't load `{settings.table_id}`.\n\n{exc}")
    st.markdown(
        "**Checklist**\n"
        "1. Connected to the VPN? (VPC Service Controls errors mean you're off the VPN.)\n"
        "2. Logged in for applications with your work account: `gcloud auth application-default login`\n"
        f"3. Can you impersonate the uploader? "
        f"`gcloud auth print-access-token --impersonate-service-account={settings.uploader_sa}`\n"
        "4. Table and dataset names right? Override with `MAPPING_TABLE` / `MAPPING_DATASET`."
    )
    if st.button("Try again"):
        st.cache_resource.clear()
        st.session_state.pop("snapshot", None)
        st.rerun()
    st.stop()

snapshot = st.session_state.snapshot
columns: list[Column] = snapshot.columns
key = settings.key_column
audit_ok, audit_message = repo.audit_status()

# --------------------------------------------------------------------------- #
# Sidebar
# --------------------------------------------------------------------------- #
with st.sidebar:
    st.header("Mapping table")
    if settings.demo:
        st.warning("Demo mode: sample data in memory. Nothing is sent to BigQuery.")
    st.caption("Table")
    st.code(settings.table_id, language=None)
    st.caption("Signed in as")
    st.write(user)
    st.caption("Saves run as")
    st.write(repo.acting_as())
    st.caption("Loaded")
    st.write(f"{len(snapshot.rows)} rows at {snapshot.loaded_at.strftime('%H:%M:%S')} UTC")

    if st.button("Reload from BigQuery", use_container_width=True, help="Discards unsaved edits."):
        reload_snapshot(repo)
        st.rerun()

    st.download_button(
        "Export table as CSV",
        data=export_csv(columns, snapshot.rows),
        file_name=f"{settings.table}.csv",
        mime="text/csv",
        use_container_width=True,
        help="Saved data only (not unsaved edits). Same columns and order as the upload script.",
    )

    st.divider()
    with st.expander("Columns to show"):
        chosen = st.multiselect(
            "Columns",
            options=[c.name for c in columns if c.name != key],
            default=[c.name for c in columns if c.name != key],
            help="Hiding a column only hides it here; its values are kept when you save.",
            label_visibility="collapsed",
        )

# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
st.title("Mapping table editor")
flash = st.session_state.pop("flash", None)
if flash:
    st.success(flash)
if not audit_ok:
    st.warning(audit_message)

edit_tab, history_tab = st.tabs(["Edit", "Change history"])

with edit_tab:
    st.caption(
        "Edit cells directly. Add rows with the + at the bottom of the table; delete by selecting rows and "
        "pressing Delete. Nothing is written until you click **Save changes**."
    )
    editor_key = f"editor_{st.session_state.editor_version}"
    st.data_editor(
        to_frame(columns, snapshot.rows),
        key=editor_key,
        num_rows="dynamic",
        hide_index=True,
        column_config=column_config(columns, key),
        column_order=[key, *chosen],
        use_container_width=True,
        height=520,
    )

    cs = build_changeset(snapshot.rows, columns, st.session_state.get(editor_key), key, user)

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Rows updated", cs.updated)
    m2.metric("Rows added", cs.added)
    m3.metric("Rows deleted", cs.deleted)
    m4.metric("Cells changed", sum(1 for a in cs.audit if a["action"] == "UPDATE"))

    if cs.errors:
        st.error("Fix these before saving:\n\n" + "\n".join(f"- {e}" for e in cs.errors))

    if cs.audit:
        with st.expander(f"Review {len(cs.audit)} change(s)", expanded=bool(cs.deletes)):
            st.dataframe(
                pd.DataFrame(cs.audit)[["action", "account_id", "column_name", "old_value", "new_value"]],
                hide_index=True,
                use_container_width=True,
            )

    confirm_delete = True
    if cs.deletes:
        confirm_delete = st.checkbox(
            f"I want to delete {cs.deleted} row(s): {', '.join(cs.deletes[:10])}{'…' if cs.deleted > 10 else ''}"
        )

    b1, b2, _ = st.columns([1, 1, 4])
    save_clicked = b1.button(
        "Save changes",
        type="primary",
        disabled=not (cs.can_save and audit_ok and confirm_delete),
        use_container_width=True,
    )
    if b2.button("Discard changes", disabled=cs.is_empty and not cs.errors, use_container_width=True):
        st.session_state.editor_version += 1
        st.rerun()

    if save_clicked:
        try:
            with st.spinner("Saving to BigQuery…"):
                repo.save(cs, columns, snapshot.version)
        except ConcurrentModificationError:
            st.error(
                "The table changed after you loaded it (another save or a CSV upload), so nothing was saved. "
                "Copy anything you need, click **Reload from BigQuery**, then make your edits again."
            )
        except Exception as exc:  # noqa: BLE001
            st.error(f"Save failed. Nothing was changed.\n\n{exc}")
        else:
            st.session_state.flash = (
                f"Saved: {cs.updated} updated, {cs.added} added, {cs.deleted} deleted "
                f"({len(cs.audit)} change(s) logged)."
            )
            reload_snapshot(repo)
            st.rerun()

with history_tab:
    if not audit_ok:
        st.info("Change history appears here once the audit table exists.")
    else:
        h1, h2, h3 = st.columns([2, 1, 1])
        account_filter = h1.text_input("Filter by account_id", placeholder="All accounts")
        limit = h2.selectbox("Show", [50, 200, 1000], index=1)
        h3.write("")
        if h3.button("Load history", use_container_width=True) or st.session_state.get("history") is None:
            try:
                st.session_state.history = repo.recent_changes(limit, account_filter.strip() or None)
            except Exception as exc:  # noqa: BLE001
                st.session_state.history = []
                st.error(f"Couldn't read the change history.\n\n{exc}")
        history = st.session_state.get("history") or []
        if history:
            st.dataframe(pd.DataFrame(history), hide_index=True, use_container_width=True)
        else:
            st.caption("No changes recorded yet.")
