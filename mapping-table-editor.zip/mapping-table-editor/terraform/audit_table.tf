# Audit table for the Streamlit mapping-table editor.
#
# Add this file (and schema/mapping_table_audit.json) to the SAME Terraform
# workspace that manages the mapping table, then let the pipeline apply it.
#
# Adjust the three marked references to match how your mapping table resource
# is written in that workspace (resource names, variables, labels).
#
# The uploader service account already has BigQuery Data Editor on the dataset,
# so it can write here; no new IAM is needed.

resource "google_bigquery_table" "mapping_audit" {
  project    = "wrk-int-wrk01-svp-cf82a1"                 # <- or var.project_id
  dataset_id = "ew2_wrk_int_wrk01_svp_bqd_reference_data" # <- or a reference to your dataset resource
  table_id   = "mapping-table-audit"

  description         = "Change log for mapping-table, written by the Streamlit editor (one row per changed cell / added / deleted row)."
  schema              = file("${path.module}/schema/mapping_table_audit.json")
  deletion_protection = true

  # Monthly partitions keep history queries cheap as the log grows.
  time_partitioning {
    type  = "MONTH"
    field = "changed_at"
  }

  # The dataset's default CMEK key (ew2-keyhsm-bigq-0de6) applies automatically.
  # If your mapping table resource sets encryption explicitly, copy that block here:
  # encryption_configuration {
  #   kms_key_name = "projects/wrk-int-wrk01-svp-cf82a1/locations/europe-west2/keyRings/ew2-krs-bigq-0de6/cryptoKeys/ew2-keyhsm-bigq-0de6"
  # }

  labels = { # <- use the same labels as the mapping table (your org requires them)
    owner               = var.owner
    cost_centre         = var.cost_centre
    data_classification = "limited"
  }
}
