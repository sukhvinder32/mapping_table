import os
from pathlib import Path

from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parents[1] / "app.py")


def test_app_renders_in_demo_mode():
    os.environ["MAPPING_DEMO"] = "1"
    at = AppTest.from_file(APP, default_timeout=60).run()
    assert not at.exception, at.exception
    assert at.title[0].value == "Mapping table editor"
    assert [m.value for m in at.metric] == ["0", "0", "0", "0"]
    save = next(b for b in at.button if b.label == "Save changes")
    assert save.disabled  # nothing to save yet
    assert any("Demo mode" in w.value for w in at.sidebar.warning)
