import json
import sys
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from changes import Column, build_changeset, coerce, merge_transaction_sql, stage_rows  # noqa: E402
from repository import ConcurrentModificationError, DemoRepository  # noqa: E402

COLS = [
    Column("title", "INT64"),
    Column("account_id", "STRING", "REQUIRED"),
    Column("business_unit", "STRING"),
    Column("environment", "STRING", "REQUIRED"),
    Column("fy_2025", "NUMERIC"),
]
ROWS = [
    {"title": 1, "account_id": "id_1", "business_unit": "Cloud", "environment": "PROD", "fy_2025": Decimal("100.50")},
    {"title": 2, "account_id": "id_2", "business_unit": None, "environment": "Dev", "fy_2025": None},
]
NOW = datetime(2026, 11, 25, 15, 0, tzinfo=timezone.utc)


def cs_for(state):
    return build_changeset(ROWS, COLS, state, "account_id", "me@bank.com", now=NOW, batch_id="b1")


# ---- coerce ----------------------------------------------------------------- #
@pytest.mark.parametrize(
    "value,bq_type,expected",
    [
        (None, "STRING", None),
        ("", "STRING", None),
        ("  ", "NUMERIC", None),
        (float("nan"), "NUMERIC", None),
        ("abc", "STRING", "abc"),
        (5.0, "INT64", 5),
        ("1,234", "INT64", 1234),
        (0.1 + 0.2, "NUMERIC", "0.3"),
        (201118.24, "NUMERIC", "201118.24"),
        (Decimal("100.50"), "NUMERIC", "100.5"),
        ("1,000.125", "NUMERIC", "1000.125"),
        ("yes", "BOOL", True),
        (3, "FLOAT64", 3.0),
    ],
)
def test_coerce(value, bq_type, expected):
    assert coerce(value, bq_type) == expected


@pytest.mark.parametrize("value,bq_type", [(2.5, "INT64"), ("x", "INT64"), ("£12", "NUMERIC"), (True, "INT64"), ("maybe", "BOOL")])
def test_coerce_rejects(value, bq_type):
    with pytest.raises(ValueError):
        coerce(value, bq_type)


# ---- change sets ------------------------------------------------------------ #
def test_no_state_means_no_changes():
    cs = cs_for(None)
    assert cs.is_empty and not cs.errors and not cs.can_save


def test_edit_cell_produces_full_row_upsert_and_audit():
    cs = cs_for({"edited_rows": {0: {"business_unit": "Data"}}})
    assert cs.can_save and cs.updated == 1
    assert cs.upserts == [{"title": 1, "account_id": "id_1", "business_unit": "Data", "environment": "PROD", "fy_2025": "100.5"}]
    (a,) = cs.audit
    assert (a["action"], a["account_id"], a["column_name"], a["old_value"], a["new_value"]) == ("UPDATE", "id_1", "business_unit", "Cloud", "Data")
    assert a["changed_by"] == "me@bank.com" and a["batch_id"] == "b1" and a["changed_at"].startswith("2026-11-25T15:00")


def test_string_row_positions_are_accepted():
    assert cs_for({"edited_rows": {"1": {"business_unit": "Ops"}}}).upserts[0]["account_id"] == "id_2"


def test_edit_back_to_same_value_is_not_a_change():
    cs = cs_for({"edited_rows": {0: {"business_unit": "Cloud", "fy_2025": 100.5}}})
    assert cs.is_empty and not cs.errors


def test_numeric_edit_and_bad_int():
    cs = cs_for({"edited_rows": {0: {"fy_2025": 0.1 + 0.2}, 1: {"title": 2.5}}})
    assert cs.upserts[0]["fy_2025"] == "0.3"
    assert any("title" in e and "whole number" in e for e in cs.errors)
    assert not cs.can_save


def test_key_cannot_change():
    cs = cs_for({"edited_rows": {0: {"account_id": "id_99"}}})
    assert cs.errors and "can't be changed" in cs.errors[0] and not cs.upserts


def test_required_column_cannot_be_blanked():
    cs = cs_for({"edited_rows": {1: {"environment": ""}}})
    assert any("environment" in e and "required" in e for e in cs.errors)


def test_delete_wins_over_edit_and_is_audited():
    cs = cs_for({"edited_rows": {1: {"business_unit": "X"}}, "deleted_rows": [1]})
    assert cs.deletes == ["id_2"] and not cs.upserts and cs.deleted == 1
    (a,) = cs.audit
    assert a["action"] == "DELETE" and json.loads(a["old_value"])["environment"] == "Dev"


def test_add_row_valid_duplicate_empty_and_missing_key():
    cs = cs_for({"added_rows": [{"account_id": "id_3", "environment": "INT", "title": 3}]})
    assert cs.added == 1 and cs.upserts[0]["account_id"] == "id_3" and cs.audit[0]["action"] == "INSERT"
    assert json.loads(cs.audit[0]["new_value"])["title"] == 3

    assert "already exists" in cs_for({"added_rows": [{"account_id": "id_1", "environment": "X"}]}).errors[0]
    dup = cs_for({"added_rows": [{"account_id": "n", "environment": "X"}, {"account_id": "n", "environment": "Y"}]})
    assert any("entered twice" in e for e in dup.errors)
    assert cs_for({"added_rows": [{}]}).is_empty  # blank row ignored
    missing = cs_for({"added_rows": [{"business_unit": "Cloud", "environment": "X"}]})
    assert any("account_id is required" in e for e in missing.errors)
    no_env = cs_for({"added_rows": [{"account_id": "id_5"}]})
    assert any("environment" in e and "required" in e for e in no_env.errors)


def test_stage_rows_and_merge_sql():
    cs = cs_for({"edited_rows": {0: {"business_unit": "Data"}}, "deleted_rows": [1]})
    rows = stage_rows(cs, COLS, "account_id")
    assert [r["_op"] for r in rows] == ["UPSERT", "DELETE"]
    assert rows[1] == {"title": None, "account_id": "id_2", "business_unit": None, "environment": None, "fy_2025": None, "_op": "DELETE"}

    sql = merge_transaction_sql("p.d.mapping-table", "p.d._tmp_s", "p.d.mapping-table-audit", "p.d._tmp_a", COLS, "account_id")
    assert sql.startswith("BEGIN TRANSACTION;") and sql.rstrip().endswith("COMMIT TRANSACTION;")
    assert "MERGE `p.d.mapping-table` AS T" in sql
    assert "ON T.`account_id` = S.`account_id`" in sql
    assert "`account_id` = S.`account_id`," not in sql  # key never updated
    for c in ("title", "business_unit", "environment", "fy_2025"):
        assert f"`{c}` = S.`{c}`" in sql
    assert "INSERT INTO `p.d.mapping-table-audit`" in sql


def test_identifier_injection_rejected():
    with pytest.raises(ValueError):
        merge_transaction_sql("p.d.t`; DROP", "s", "a", "as", COLS, "account_id")


# ---- demo repository round trip --------------------------------------------- #
def test_demo_repository_save_and_conflict():
    repo = DemoRepository(ROOT / "data/demo/MappingTable.csv", ROOT / "data/demo/mapping_table.json")
    snap = repo.load()
    assert len(snap.rows) == 30 and len(snap.columns) == 67
    pos = next(i for i, r in enumerate(snap.rows) if r["account_id"] == "id_00036")
    state = {
        "edited_rows": {pos: {"environment": "PRE-PROD"}},
        "added_rows": [{"account_id": "id_NEW", "business_unit": "FinOps"}],
        "deleted_rows": [0],
    }
    cs = build_changeset(snap.rows, snap.columns, state, "account_id", "me@bank.com")
    assert cs.can_save, cs.errors
    repo.save(cs, snap.columns, snap.version)

    after = {r["account_id"]: r for r in repo.load().rows}
    assert after["id_00036"]["environment"] == "PRE-PROD"
    assert after["id_00036"]["fy_2025"] is None and after["id_00036"]["title"] == 18  # untouched values kept
    assert after["id_NEW"]["business_unit"] == "FinOps"
    assert snap.rows[0]["account_id"] not in after
    assert len(after) == 30
    assert {a["action"] for a in repo.recent_changes()} == {"UPDATE", "INSERT", "DELETE"}

    with pytest.raises(ConcurrentModificationError):  # stale snapshot
        repo.save(cs, snap.columns, snap.version)
