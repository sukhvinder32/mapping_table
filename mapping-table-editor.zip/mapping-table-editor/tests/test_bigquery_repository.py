"""BigQueryRepository against a mocked BigQuery client (no network)."""
import sys
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from google.api_core.exceptions import BadRequest
from google.cloud import bigquery

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from changes import build_changeset  # noqa: E402
from config import load_settings  # noqa: E402
from repository import BigQueryRepository, ConcurrentModificationError  # noqa: E402

T0 = datetime(2026, 11, 25, 15, 0, tzinfo=timezone.utc)
SCHEMA = [
    bigquery.SchemaField("title", "INTEGER", description="Source column: Title"),
    bigquery.SchemaField("account_id", "STRING", mode="REQUIRED"),
    bigquery.SchemaField("business_unit", "STRING"),
    bigquery.SchemaField("fy_2025", "NUMERIC"),
]


def make_repo():
    repo = BigQueryRepository.__new__(BigQueryRepository)
    repo.s = load_settings()
    repo._bq = bigquery
    repo._email = "me@bank.com"
    repo.client = MagicMock()
    table = SimpleNamespace(schema=SCHEMA, modified=T0)
    repo.client.get_table.return_value = table
    repo.client.list_rows.return_value = [
        {"title": 2, "account_id": "id_2", "business_unit": None, "fy_2025": None},
        {"title": 1, "account_id": "id_1", "business_unit": "Cloud", "fy_2025": Decimal("1.5")},
    ]
    return repo


def test_load_sorts_rows_and_reads_schema():
    snap = make_repo().load()
    assert [r["account_id"] for r in snap.rows] == ["id_1", "id_2"]
    assert snap.columns[0].type == "INTEGER" and snap.columns[1].required
    assert snap.version == T0.isoformat()


def test_save_stages_merges_with_cmek_and_cleans_up():
    repo = make_repo()
    snap = repo.load()
    cs = build_changeset(snap.rows, snap.columns, {"edited_rows": {0: {"business_unit": "Data"}}}, "account_id", "me@bank.com")
    repo.save(cs, snap.columns, snap.version)

    created = [c.args[0] for c in repo.client.create_table.call_args_list]
    assert len(created) == 2
    for t in created:
        assert t.expires is not None
        assert t.encryption_configuration.kms_key_name.endswith("cryptoKeys/ew2-keyhsm-bigq-0de6")

    loads = repo.client.load_table_from_json.call_args_list
    assert len(loads) == 2
    stage_rows = loads[0].args[0]
    assert stage_rows == [{"title": 1, "account_id": "id_1", "business_unit": "Data", "fy_2025": "1.5", "_op": "UPSERT"}]
    assert loads[0].kwargs["job_config"].destination_encryption_configuration.kms_key_name.endswith("ew2-keyhsm-bigq-0de6")
    assert loads[1].args[0][0]["action"] == "UPDATE"

    sql, = repo.client.query.call_args.args
    assert "MERGE `wrk-int-wrk01-svp-cf82a1.ew2_wrk_int_wrk01_svp_bqd_reference_data.mapping-table`" in sql
    assert "INSERT INTO `wrk-int-wrk01-svp-cf82a1.ew2_wrk_int_wrk01_svp_bqd_reference_data.mapping-table-audit`" in sql
    assert repo.client.query.call_args.kwargs["job_config"].destination_encryption_configuration is not None
    assert repo.client.delete_table.call_count == 2  # both stage tables removed


def test_stage_tables_removed_even_when_merge_fails():
    repo = make_repo()
    snap = repo.load()
    cs = build_changeset(snap.rows, snap.columns, {"edited_rows": {0: {"business_unit": "Data"}}}, "account_id", "x")
    repo.client.query.side_effect = BadRequest("boom")
    with pytest.raises(BadRequest):
        repo.save(cs, snap.columns, snap.version)
    assert repo.client.delete_table.call_count == 2


def test_concurrent_change_blocks_save():
    repo = make_repo()
    snap = repo.load()
    cs = build_changeset(snap.rows, snap.columns, {"edited_rows": {0: {"business_unit": "Data"}}}, "account_id", "x")
    repo.client.get_table.return_value = SimpleNamespace(schema=SCHEMA, modified=datetime(2026, 11, 25, 16, 0, tzinfo=timezone.utc))
    with pytest.raises(ConcurrentModificationError):
        repo.save(cs, snap.columns, snap.version)
    repo.client.create_table.assert_not_called()


def test_query_retries_without_key_only_when_key_setting_rejected():
    repo = make_repo()
    ok = MagicMock()
    ok.result.return_value = []
    repo.client.query.side_effect = [BadRequest("Cannot set destination encryption configuration for scripts"), ok]
    repo._query("SELECT 1")
    first, second = repo.client.query.call_args_list
    assert first.kwargs["job_config"].destination_encryption_configuration is not None
    assert second.kwargs["job_config"].destination_encryption_configuration is None

    repo.client.query.side_effect = [BadRequest("Syntax error")]
    with pytest.raises(BadRequest):
        repo._query("SELEC 1")
